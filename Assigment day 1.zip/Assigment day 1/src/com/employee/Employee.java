package com.employee;
public class Employee {
    String name=new String("Ram");
    String name1=new String("Ramesh");
    int age=30;
    int age1=40;
    String city=new String("Mumbai");
    String city1=new String("Goa");
    void display(){
        System.out.println("The name is "+name);
        System.out.println("The age is "+age);
        System.out.println("The city is "+city);
    }
    void display1(){
        System.out.println("The name is "+name1);
        System.out.println("The age is "+age1);
        System.out.println("The city is "+city1);
    }
}
