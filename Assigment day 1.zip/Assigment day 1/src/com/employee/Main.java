package com.employee;
public class Main {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.display();
        Employee e1 = new Employee();
        e1.display1();
    }
}
